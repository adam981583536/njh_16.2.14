//
//  UIView+QFExt.h
//  MyFreeLimit
//
//  Created by mac on 14-1-3.
//  Copyright (c) 2014年 张健. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIView (QFExt)
- (void) makeCorner:(float)r;
- (float) width;
- (float) height;
@end
